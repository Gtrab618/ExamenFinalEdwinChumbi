package com.example.albums;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.albums.model.albumn;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> datos= new ArrayList<>();
    ArrayAdapter arrayAdapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listViewAlbumn);

        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,datos);
        listView.setAdapter(arrayAdapter);

        obtenerDatos();
    }

    private void obtenerDatos(){
        String url= "https://jsonplaceholder.typicode.com/albums";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                manejarJson(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG);
            }
        });
        //get peticion
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void manejarJson(JSONArray jsonArray){

        JSONObject jsonObject= null;

        for (int i=0; i<jsonArray.length(); i++){

            try {
                jsonObject= jsonArray.getJSONObject(i);
                albumn alb= new albumn();

                alb.setId(jsonObject.getInt("id"));
                alb.setUserId(jsonObject.getInt("userId"));
                alb.setTitle(jsonObject.getString("title"));

                datos.add("Title:"+alb.getTitle()+"\n" +"UserId: "+alb.getUserId() +"\n" +"Id: "+alb.getId());

            }catch (JSONException e){
                e.printStackTrace();
            }
        }

        arrayAdapter.notifyDataSetChanged();

    }

    public void siguienteActi(View view){
        Intent  siguiente = new Intent(this,post.class);

        startActivity(siguiente);
    }

}