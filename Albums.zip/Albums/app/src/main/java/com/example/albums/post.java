package com.example.albums;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.albums.R;

import org.json.JSONException;
import org.json.JSONObject;

public class post extends AppCompatActivity {

    EditText et_titulo , et_id, et_userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        et_titulo=(EditText) findViewById(R.id.txt_titulo);
        et_id=(EditText) findViewById(R.id.txt_id);
        et_userId=(EditText) findViewById(R.id.txt_idUser);
    }

    public void Registrar(View view)  {

        String titulo = et_titulo.getText().toString();
        String id= et_id.getText().toString();
        String userId= et_userId.getText().toString();

        if(!titulo.isEmpty() && !id.isEmpty() && !userId.isEmpty() ){
            JSONObject postData = new JSONObject();
            try {
                postData.put("title",titulo);
                postData.put("id",id);
                postData.put("userId",userId);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }


            String url = "https://jsonplaceholder.typicode.com/albums";
            
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Toast.makeText(post.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Toast.makeText(post.this, "Registro fallido", Toast.LENGTH_SHORT).show();
                }   
            });
            Volley.newRequestQueue(this).add( request);
        }else{

            Toast.makeText(this, "Faltan datos", Toast.LENGTH_SHORT).show();
        }


    }

    public void volver(View view){

            finish();
    }
}